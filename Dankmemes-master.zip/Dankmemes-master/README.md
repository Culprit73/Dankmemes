<html>
  <head>
  <title> What are you? Fucking gay? </title>
  <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet" type="text/css">
<style>
    img.TheThing{
      opacity: .5;
    }
    div{
      align="center";
      text-align: center;
      font-family: 'Lobster', cursive;
      font-size: 150%;
    }
    h1.InteriorCrocodileAlligator{
      font-size: 200%;
      font-family: 'Lobster', cursive;
    }
    p.DeezNutz{
      font-family: 'Lobster', cursive;
      font-size: 150%;
    }
    body{
      background-image: url("https://media.giphy.com/media/cl1S8bSWOOVwc/giphy.gif");
      background-color: black;
    }
  </style>
